package Plugins::CamillaMellow::Settings;

use strict;
use warnings;

our $log = sub { warn "CamillaMellow: " . join(' ', @_) . "\n" };

sub init {
    # Log semplice
    $log->("Settings module loaded");
    
    # Registra pagine web se disponibili
    eval {
        require Slim::Web::Pages;
        Slim::Web::Pages->addPageFunction(
            'plugins/CamillaFIR/settings/basic.html',
            \&basicSettings
        );
    };
    
    if ($@) {
        $log->("Web interface not available: $@");
    }
}

sub basicSettings {
    my ($client, $params) = @_;
    
    # Log richiesta
    $log->("Basic settings requested");
    
    # Ritorna HTML semplice
    return <<"HTML";
<div class="settingsSection">
    <div class="prefHead">🎵 CamillaMellow DSP v0.2.0</div>
    <p>✅ Plugin loaded successfully!</p>
    <p>📊 FIR processing ready for REW integration</p>
    <p>🎯 By Informatica Melizzi</p>
</div>
HTML
}

1;
