package Plugins::CamillaMellow::Plugin;

use strict;
use warnings;

# Versione compatibile Daphile - senza Slim::Plugin::Base
our $VERSION = '0.2.0';

sub initPlugin {
    my $class = shift;
    
    # Log semplice
    warn "CamillaMellow plugin v$VERSION initializing";
    
    # Inizializza moduli GUI
    eval {
        require Plugins::CamillaMellow::Settings;
        Plugins::CamillaMellow::Settings->init();
    };
    
    if ($@) {
        warn "Error loading Settings: $@";
    }
    
    return 1;
}

sub getDisplayName {
    return 'CamillaMellow DSP';
}

1;
